<<<<<<< HEAD
# landing-page-food-delivery-app
landing page for food delivery app - HTML - CSS - JS
=======
# Web-based food delivery application
#Order and get food delivered
>>>>>>> b0e39999f223db6ffb4e9aa6e37051e9a2bb8de6
